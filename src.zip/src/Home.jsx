import React from "react";

export default function Home() {
  return (
    <div
      className="flex min-h-screen flex-col bg-cover bg-center"
      style={{
        backgroundImage:
          "url('https://images.unsplash.com/photo-1503264116251-35a269479413?auto=format&fit=crop&w=1920&q=80')",
      }}
    >
      {/* Main Content */}
      <div className="space-y-8 flex-grow">
        <section>
          <h1 className="mb-4 mt-6 text-3xl font-semibold text-center text-white">
            Welcome to My Website ✨
          </h1>
          <p className="text-center text-lg max-w-2xl mx-auto text-gray-100">
            Explore a clean, modern Tailwind UI with a frosted background,
            soft shadows, and a responsive layout.
          </p>
        </section>

        {/* Features */}
        <section className="mt-8">
          <h2 className="mb-6 text-center text-2xl font-semibold text-white">
            Features
          </h2>
          <div className="grid grid-cols-1 gap-6 px-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            <div className="rounded-2xl bg-white/30 backdrop-blur-md hover:bg-white/40 p-6 text-black text-center font-medium shadow-md transition">
              🌟 Feature 1
            </div>
            <div className="rounded-2xl bg-white/30 backdrop-blur-md hover:bg-white/40 p-6 text-black text-center font-medium shadow-md transition">
              💡 Feature 2
            </div>
            <div className="rounded-2xl bg-white/30 backdrop-blur-md hover:bg-white/40 p-6 text-black text-center font-medium shadow-md transition">
              ⚡ Feature 3
            </div>
            <div className="rounded-2xl bg-white/30 backdrop-blur-md hover:bg-white/40 p-6 text-black text-center font-medium shadow-md transition">
              🔒 Feature 4
            </div>
            <div className="rounded-2xl bg-white/30 backdrop-blur-md hover:bg-white/40 p-6 text-black text-center font-medium shadow-md transition">
              🚀 Feature 5
            </div>
            <div className="rounded-2xl bg-white/30 backdrop-blur-md hover:bg-white/40 p-6 text-black text-center font-medium shadow-md transition">
              🎨 Feature 6
            </div>
            <div className="rounded-2xl bg-white/30 backdrop-blur-md hover:bg-white/40 p-6 text-black text-center font-medium shadow-md transition">
              🔔 Feature 7
            </div>
            <div className="rounded-2xl bg-white/30 backdrop-blur-md hover:bg-white/40 p-6 text-black text-center font-medium shadow-md transition">
              🧠 Feature 8
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}


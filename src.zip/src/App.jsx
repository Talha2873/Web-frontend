import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./Home";
import About from "./About";
import Profile from "./Profile";

export default function App() {
  return (
    <Router>
      <div
        className="flex min-h-screen flex-col bg-gray-200 text-black bg-cover bg-center min-w-screen"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1503264116251-35a269479413?auto=format&fit=crop&w=1920&q=80')",
        }}
      >
        {/* ✅ Navbar */}
        <nav className="p-4 bg-gray-800/70 backdrop-blur-md text-white flex justify-between items-center shadow-md">
          <div className="flex space-x-6 font-medium">
            <Link
              to="/"
              className="hover:text-blue-300 transition-colors duration-200"
            >
              Home
            </Link>
            <Link
              to="/about"
              className="hover:text-blue-300 transition-colors duration-200"
            >
              About
            </Link>

            <Link to="/Profile"
             className="hover:text-blue-300 cursor-pointer">Profile
             </Link>
          </div>

          <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded shadow transition">
            Get Started
          </button>
        </nav>

        {/* ✅ Route Views */}
        <div className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
             <Route path="/profile" element={<Profile />} /> 
          </Routes>
        </div>

        {/* ✅ Footer */}
        <footer className="bg-gray-900/80 backdrop-blur-md py-6 text-center text-sm text-white mt-auto">
          &copy; 2025 My Website. All rights reserved.
        </footer>
      </div>
    </Router>
  );
}

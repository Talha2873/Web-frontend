import React from "react";

export default function Profile() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-700 text-white flex flex-col items-center justify-center px-6 py-12">
      {/* Header */}
      <h1 className="text-4xl sm:text-5xl font-bold mb-6 text-center">
        My Profile 👤
      </h1>

      {/* Profile Card */}
      <div className="bg-white/10 backdrop-blur-lg rounded-3xl shadow-2xl p-8 max-w-md w-full text-center">
        <img
          src="https://randomuser.me/api/portraits/men/45.jpg"
          alt="Profile Avatar"
          className="w-32 h-32 rounded-full mx-auto border-4 border-blue-500 shadow-md mb-4"
        />
        <h2 className="text-2xl font-semibold mb-1">M. Talha Ilyas</h2>
        <p className="text-blue-400 font-medium mb-4">Full Stack Developer</p>

        <p className="text-gray-300 mb-6">
          Passionate about crafting modern web apps using React, Tailwind CSS,
          and AI integration. Always eager to learn and innovate. 🚀
        </p>

        <div className="flex justify-center space-x-4 mb-6">
          <button className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg text-white font-medium transition">
            Edit Profile
          </button>
          <button className="bg-gray-700 hover:bg-gray-800 px-4 py-2 rounded-lg text-white font-medium transition">
            Settings
          </button>
        </div>

        {/* Social Links */}
        <div className="flex justify-center space-x-6 text-gray-400">
          <a
            href="#"
            className="hover:text-blue-400 transition"
            aria-label="GitHub"
          >
            <i className="fab fa-github text-2xl"></i>
          </a>
          <a
            href="#"
            className="hover:text-blue-400 transition"
            aria-label="LinkedIn"
          >
            <i className="fab fa-linkedin text-2xl"></i>
          </a>
          <a
            href="#"
            className="hover:text-blue-400 transition"
            aria-label="Twitter"
          >
            <i className="fab fa-twitter text-2xl"></i>
          </a>
        </div>
      </div>

      {/* Footer */}
      <footer className="mt-16 text-gray-500 text-sm">
        &copy; 2025 My Website. All rights reserved.
      </footer>
    </div>
  );
}

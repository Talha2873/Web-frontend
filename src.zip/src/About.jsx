import React from "react";

export default function About() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-700 text-white flex flex-col items-center justify-center px-6 py-12">
      {/* Header */}
      <h1 className="text-4xl sm:text-5xl font-bold mb-4 text-center">
        About Us 💼
      </h1>
      <p className="text-gray-300 text-center max-w-2xl mb-10">
        Welcome to <span className="font-semibold text-blue-400">My Website</span>!  
        We’re a passionate team focused on delivering clean, modern web experiences 
        using React and Tailwind CSS. Our goal is to build fast, elegant, and responsive 
        applications that users love.
      </p>

      {/* Team Section */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 mt-8 max-w-5xl">
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 text-center hover:bg-white/20 transition shadow-lg">
          <img
            src="https://randomuser.me/api/portraits/men/32.jpg"
            alt="Team Member"
            className="w-24 h-24 mx-auto rounded-full mb-4 border-2 border-blue-400"
          />
          <h3 className="text-xl font-semibold mb-1">John Doe</h3>
          <p className="text-gray-400">Frontend Developer</p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 text-center hover:bg-white/20 transition shadow-lg">
          <img
            src="https://randomuser.me/api/portraits/women/45.jpg"
            alt="Team Member"
            className="w-24 h-24 mx-auto rounded-full mb-4 border-2 border-blue-400"
          />
          <h3 className="text-xl font-semibold mb-1">Sarah Smith</h3>
          <p className="text-gray-400">UI/UX Designer</p>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 text-center hover:bg-white/20 transition shadow-lg">
          <img
            src="https://randomuser.me/api/portraits/men/67.jpg"
            alt="Team Member"
            className="w-24 h-24 mx-auto rounded-full mb-4 border-2 border-blue-400"
          />
          <h3 className="text-xl font-semibold mb-1">Michael Lee</h3>
          <p className="text-gray-400">Backend Engineer</p>
        </div>
      </div>

      {/* Mission Section */}
      <div className="max-w-3xl text-center mt-12">
        <h2 className="text-2xl font-semibold mb-4 text-blue-400">
          Our Mission 🚀
        </h2>
        <p className="text-gray-300 leading-relaxed">
          We aim to create impactful web experiences through modern technologies 
          and clean design. Every project is a step towards innovation and user satisfaction.
        </p>
      </div>

      {/* Footer */}
      <footer className="mt-16 text-gray-500 text-sm">
        &copy; 2025 My Website. All rights reserved.
      </footer>
    </div>
  );
}

